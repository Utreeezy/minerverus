./hellminer -c stratum+tcp://eu.luckpool.net:3960 -u RBi3chHs5ktxtq3oLBvF9CUyE7PVprxrNn.1 -p x
